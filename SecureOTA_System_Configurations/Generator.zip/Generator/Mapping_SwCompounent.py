from typing import Mapping
import xml.etree.ElementTree as ET

class MappingParser:
    def __init__(self, xmlString):
        self.xmlString = xmlString
        print("Mapping Parser")

    def Parse(self):
        Mapping = {}
        return Mapping



class SWParser:
    def __init__(self, xmlString):
        self.xmlString = xmlString
        print("SW Parser")

    def Parse(Parent):
        SW = {}
        return SW